import streamlit as st

st.set_page_config(
    page_title="Loyalty Points Calculator",
    page_icon="🎁",
    layout="centered"
)

st.title("🎁 Loyalty Points Calculator")
st.subheader("Rewarding Every Purchase!")
st.write("Calculate your loyalty points and discounts easily.")

st.divider()

# Customer details
st.header("Customer Details")

name = st.text_input("Enter Customer Name")
customer_id = st.text_input("Enter Customer ID")
amount = st.number_input(
    "Enter Purchase Amount (₹)",
    min_value=0.0,
    step=100.0
)

if st.button("Calculate Loyalty Points"):

    if name.strip() == "" or customer_id.strip() == "":
        st.warning("Please enter customer details.")

    elif amount <= 0:
        st.warning("Please enter a valid purchase amount.")

    else:
        if amount >= 5000:
            points = int(amount // 100)
            discount = 20
        elif amount >= 3000:
            points = int(amount // 100)
            discount = 15
        elif amount >= 1000:
            points = int(amount // 100)
            discount = 10
        else:
            points = int(amount // 200)
            discount = 0

        discount_amount = amount * discount / 100
        final_amount = amount - discount_amount

        st.success("Calculation Completed!")

        st.header("Customer Bill")

        st.write("Customer Name:", name)
        st.write("Customer ID:", customer_id)

        st.metric("Purchase Amount", f"₹{amount:.2f}")
        st.metric("Loyalty Points Earned", points)
        st.metric("Discount", f"{discount}%")

        st.write("Discount Amount:", f"₹{discount_amount:.2f}")

        st.success(f"Final Amount: ₹{final_amount:.2f}")

        st.balloons()

st.divider()

st.subheader("🎉 Loyalty Rewards")
st.write("₹1,000 - 10% Discount")
st.write("₹3,000 - 15% Discount")
st.write("₹5,000 - 20% Discount")

st.caption("Thank you for shopping with us!")